 let userBtn = document.getElementById("userBtn");
    let adminBtn = document.getElementById("adminBtn");
    let userForm = document.getElementById("userForm");
    let adminForm = document.getElementById("adminForm");

    userBtn.onclick = () => {
        userBtn.classList.add("active");
        adminBtn.classList.remove("active");
        userForm.classList.add("active");
        adminForm.classList.remove("active");
    };

    adminBtn.onclick = () => {
        adminBtn.classList.add("active");
        userBtn.classList.remove("active");
        adminForm.classList.add("active");
        userForm.classList.remove("active");
    };

    // USER LOGIN
document.getElementById("userForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let userId = document.getElementById("userId").value;
    let userPass = document.getElementById("userPass").value;

    if (userId === "user001" && userPass === "user123") {
        window.location.href="./user.html"
    } else {
        alert("Invalid User ID or Password");
    }
});

// ADMIN LOGIN
document.getElementById("adminForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let adminId = document.getElementById("adminId").value;
    let adminPass = document.getElementById("adminPass").value;

    if (adminId === "admin001" && adminPass === "admin123") {
        window.location.href="./admin.html"
    } else {
        alert("Invalid Admin ID or Password");
    }
});
