package com.example.management.service.Impl;

import com.example.management.Dto.Account_dto;
import com.example.management.entity.Account;
import com.example.management.mapper.Account_mapper;
import com.example.management.repository.Account_Repo;
import com.example.management.service.Account_service;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class Account_Service_impl implements  Account_service {

    private Account_Repo account_repo;

    public Account_Service_impl(Account_Repo account_repo) {
        this.account_repo = account_repo;
    }

    @Override
    public Account_dto createAccount(Account_dto account_dto) {
        Account account= Account_mapper.mapToaccount(account_dto);
        Account savedAccount=account_repo.save(account);
        return Account_mapper.mapToaccount_dto(savedAccount);
    }

    @Override
    public Account_dto getaccountById(Long id) {
        Account account=account_repo.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));
        return Account_mapper.mapToaccount_dto(account);
    }

    @Override
    public Account_dto deposit(Long id, double amount) {
        Account account=account_repo.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));

        double total=account.getBalance()+amount;
        account.setBalance(total);
        Account savedAccount= account_repo.save(account);
        return Account_mapper.mapToaccount_dto(savedAccount);
    }

    @Override
    public Account_dto withdraw(Long id, double amount) {
        Account account=account_repo.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));
        if (account.getBalance()<amount)
            throw new RuntimeException("Insufficient Balance");
        double total=account.getBalance()-amount;
        account.setBalance(total);
        Account savedAccount= account_repo.save(account);

        return Account_mapper.mapToaccount_dto(savedAccount);
    }

    @Override
    public List<Account_dto> getAllAccount() {
        List<Account> accounts=account_repo.findAll();
        return  accounts.stream().map((account)->Account_mapper.mapToaccount_dto(account)).collect(Collectors.toList());
    }

    @Override
    public void deleteAccount(Long id) {
        Account account=account_repo.findById(id).orElseThrow(()->new RuntimeException("Account does not exist"));
        account_repo.deleteById(id);
    }
}
