package com.example.management.mapper;

import com.example.management.Dto.Account_dto;
import com.example.management.entity.Account;

public class Account_mapper {

    //this method is used to change the accountdto into JPA type

    public  static Account mapToaccount(Account_dto account_dto){
        Account account=new Account(
                account_dto.getId(),
                account_dto.getAccountHolderName(),

                account_dto.getBalance()
        );
        return account;
    }

    public  static Account_dto mapToaccount_dto(Account account){
        Account_dto account_dto=new Account_dto(
                account.getId(),
                account.getAccountHolderName(),

                account.getBalance()
        );
        return account_dto;
    }
}
