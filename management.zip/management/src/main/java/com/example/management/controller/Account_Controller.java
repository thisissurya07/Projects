package com.example.management.controller;

import com.example.management.Dto.Account_dto;
import com.example.management.mapper.Account_mapper;
import com.example.management.service.Account_service;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/accounts")
public class Account_Controller {

    private Account_service account_service;

    public Account_Controller(Account_service account_service) {

        this.account_service = account_service;
    }

    // Add account REST Api
    @PostMapping
    public ResponseEntity<Account_dto> addAccount(@RequestBody Account_dto account_dto){
        return  new ResponseEntity<>(account_service.createAccount(account_dto), HttpStatus.CREATED);
    }
    //Get account by id
    @GetMapping("/{id}")
    public  ResponseEntity<Account_dto>getAccountById(@PathVariable  Long id){
        Account_dto account_dto=account_service.getaccountById(id);
        return ResponseEntity.ok(account_dto);
    }
    // deposit account by id
    @PutMapping("/{id}/deposit")
    public ResponseEntity<Account_dto>depositAccount(@PathVariable Long id ,@RequestBody Map<String,Double>request){

        Double amount=request.get("amount");
        Account_dto account_dto=account_service.deposit(id,request.get("amount"));
        return ResponseEntity.ok(account_dto);
    }
    // withdraw by id
    @PutMapping("/{id}/withdraw")
    public  ResponseEntity<Account_dto>withdrawAccount(@PathVariable Long id , @RequestBody Map<String , Double>request){
        double amount=request.get("amount");
        Account_dto account_dto=account_service.withdraw(id,amount);
        return ResponseEntity.ok(account_dto);
    }

    // get all accounts
    @GetMapping
    public  ResponseEntity<List<Account_dto>> getAllAccounts(){
        List<Account_dto> accounts=account_service.getAllAccount();
        return ResponseEntity.ok(accounts);
    }

    // delete Account by id
    @DeleteMapping("/{id}")
    public ResponseEntity<String>deleteAccount(@PathVariable Long id){
        account_service.deleteAccount(id);
        return ResponseEntity.ok(" Account Deleted Successfully");
    }

}
