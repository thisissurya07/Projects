package com.example.management.repository;

import com.example.management.entity.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Account_Repo extends JpaRepository<Account,Long> {



}
