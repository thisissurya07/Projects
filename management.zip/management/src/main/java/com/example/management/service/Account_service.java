package com.example.management.service;

import com.example.management.Dto.Account_dto;

import java.util.List;


public interface Account_service {

    Account_dto createAccount(Account_dto account_dto);

    Account_dto getaccountById(Long id);

    Account_dto deposit(Long id,double amount);

    Account_dto withdraw(Long id,double amount);

    List<Account_dto>getAllAccount();

    void deleteAccount(Long id);

}
